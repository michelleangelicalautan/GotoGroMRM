import styled from "styled-components"

export const CheckableContainer = styled.div`
  display: flex;
  align-items: center;

  height: 36px;

  user-select: none;
`
