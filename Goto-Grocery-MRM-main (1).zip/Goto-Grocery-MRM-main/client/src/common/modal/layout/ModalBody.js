import styled from "styled-components"

export const ModalBody = styled.div`
  padding: 0 16px 16px;
`
