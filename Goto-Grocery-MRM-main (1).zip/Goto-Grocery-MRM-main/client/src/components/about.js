import React from "react";
/**
 * @description This is the about me page
 * @param {string} a this variable holds the name of the member
 * @returns html element template
 */
export default function About(a) {
  // This following section will display the table with the records of individuals.
  return (
    <div>
      <h3>About me</h3>
      
    </div>
  );
}
